import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";

export default function useTechnician(user) {
  const { data: technician, isLoading } = useQuery({
    queryKey: ["my-technician", user?.email],
    queryFn: async () => {
      const rows = await base44.entities.Technician.filter({ email: user.email }, "-created_date", 1);
      return rows[0] || null;
    },
    enabled: !!user?.email,
    staleTime: 5 * 60 * 1000,
  });
  return { technician, isTechnician: !!technician, isLoading };
}