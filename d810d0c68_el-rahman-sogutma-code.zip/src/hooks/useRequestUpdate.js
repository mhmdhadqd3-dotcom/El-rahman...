import { useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";

// All ServiceRequest list queries that should update optimistically
const REQUEST_QUERY_ROOTS = ["my-requests", "all-requests", "tech-jobs", "open-jobs"];

/**
 * Optimistically updates a ServiceRequest in every cached list before the API call,
 * rolls back all snapshots on error, and refetches when settled.
 */
export default function useRequestUpdate() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, data }) => base44.entities.ServiceRequest.update(id, data),
    onMutate: async ({ id, data }) => {
      await Promise.all(REQUEST_QUERY_ROOTS.map((root) => queryClient.cancelQueries({ queryKey: [root] })));
      const snapshots = [];
      REQUEST_QUERY_ROOTS.forEach((root) => {
        queryClient.getQueriesData({ queryKey: [root] }).forEach(([key, prev]) => {
          snapshots.push([key, prev]);
          queryClient.setQueryData(key, (old = []) =>
            old.map((r) => (r.id === id ? { ...r, ...data } : r))
          );
        });
      });
      return { snapshots };
    },
    onError: (_error, _vars, context) => {
      (context?.snapshots || []).forEach(([key, prev]) => queryClient.setQueryData(key, prev));
    },
    onSettled: () => {
      REQUEST_QUERY_ROOTS.forEach((root) => queryClient.invalidateQueries({ queryKey: [root] }));
    },
  });
}