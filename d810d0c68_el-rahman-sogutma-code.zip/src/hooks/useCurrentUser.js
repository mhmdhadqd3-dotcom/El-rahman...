import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";

export default function useCurrentUser() {
  const { data: user, isLoading } = useQuery({
    queryKey: ["me"],
    queryFn: () => base44.auth.me(),
    staleTime: 5 * 60 * 1000,
  });
  return { user, isLoading, isAdmin: user?.role === "admin" };
}