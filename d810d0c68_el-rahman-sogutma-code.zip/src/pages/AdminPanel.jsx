import React, { useEffect, useState } from "react";
import { Link, Navigate } from "react-router-dom";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Loader2, Search } from "lucide-react";
import { base44 } from "@/api/base44Client";
import useCurrentUser from "@/hooks/useCurrentUser";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import PageTitle from "@/components/common/PageTitle";
import PullToRefresh from "@/components/common/PullToRefresh";
import AdminRequestCard from "@/components/admin/AdminRequestCard";
import { useLanguage } from "@/lib/i18n";

const REFRESH_KEYS = [["all-requests"]];
const GROUPS = {
  yeni: ["alindi"],
  aktif: ["onaylandi", "yolda"],
  gecmis: ["tamamlandi", "reddedildi", "iptal"],
};

export default function AdminPanel() {
  const { isAdmin, isLoading: userLoading } = useCurrentUser();
  const queryClient = useQueryClient();
  const [tab, setTab] = useState("yeni");
  const [q, setQ] = useState("");
  const { t } = useLanguage();
  const { data: requests = [], isLoading } = useQuery({
    queryKey: ["all-requests"],
    queryFn: () => base44.entities.ServiceRequest.list("-created_date", 300),
    enabled: isAdmin,
  });
  const refresh = () => queryClient.invalidateQueries({ queryKey: ["all-requests"] });

  useEffect(() => base44.entities.ServiceRequest.subscribe(() => {
    queryClient.invalidateQueries({ queryKey: ["all-requests"] });
  }), [queryClient]);

  if (userLoading) return null;
  if (!isAdmin) return <Navigate to="/" replace />;

  const term = q.toLowerCase();
  const count = (g) => requests.filter((r) => GROUPS[g].includes(r.status)).length;
  const shown = requests.filter((r) => GROUPS[tab].includes(r.status) &&
    (!term || r.customer_name?.toLowerCase().includes(term) || r.customer_phone?.includes(term)));

  return (
    <PullToRefresh queryKeys={REFRESH_KEYS}>
      <PageTitle
        eyebrow={t("admin_eyebrow")} title={t("admin_title")} subtitle={t("admin_subtitle")}
        action={<Button asChild variant="outline" className="rounded-full h-11 px-5 shrink-0"><Link to="/teknisyenler">{t("techs")}</Link></Button>}
      />
      <div className="space-y-4 mb-6">
        <Tabs value={tab} onValueChange={setTab}>
          <TabsList className="w-full h-14 rounded-full p-1">
            <TabsTrigger value="yeni" className="flex-1 rounded-full h-11">{t("tab_new")} ({count("yeni")})</TabsTrigger>
            <TabsTrigger value="aktif" className="flex-1 rounded-full h-11">{t("tab_active")} ({count("aktif")})</TabsTrigger>
            <TabsTrigger value="gecmis" className="flex-1 rounded-full h-11">{t("tab_past")}</TabsTrigger>
          </TabsList>
        </Tabs>
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder={t("search_ph")} className="h-12 pl-11 rounded-full" />
        </div>
      </div>
      {isLoading ? (
        <div className="flex justify-center py-20"><Loader2 className="w-6 h-6 animate-spin text-primary" /></div>
      ) : shown.length === 0 ? (
        <p className="text-center text-muted-foreground py-16">{t("admin_empty")}</p>
      ) : (
        <div className="space-y-4">{shown.map((r) => <AdminRequestCard key={r.id} request={r} onChanged={refresh} />)}</div>
      )}
    </PullToRefresh>
  );
}