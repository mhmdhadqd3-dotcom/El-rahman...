import React, { useEffect } from "react";
import { Navigate } from "react-router-dom";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import useCurrentUser from "@/hooks/useCurrentUser";
import useTechnician from "@/hooks/useTechnician";
import PageTitle from "@/components/common/PageTitle";
import PullToRefresh from "@/components/common/PullToRefresh";
import TechnicianJobCard from "@/components/technician/TechnicianJobCard";
import { useLanguage } from "@/lib/i18n";

export default function TechnicianPanel() {
  const { user, isLoading: userLoading } = useCurrentUser();
  const { technician, isTechnician, isLoading: techLoading } = useTechnician(user);
  const { t } = useLanguage();
  const queryClient = useQueryClient();
  const { data: mine = [], isLoading } = useQuery({
    queryKey: ["tech-jobs", technician?.id],
    queryFn: () => base44.entities.ServiceRequest.filter({ technician_id: technician.id }, "-created_date", 100),
    enabled: !!technician,
  });
  const { data: fresh = [], isLoading: freshLoading } = useQuery({
    queryKey: ["open-jobs"],
    queryFn: () => base44.entities.ServiceRequest.filter({ status: "alindi" }, "-created_date", 100),
    enabled: !!technician,
  });
  const openJobs = fresh.filter((j) => !j.technician_id);
  const refresh = () => {
    queryClient.invalidateQueries({ queryKey: ["tech-jobs"] });
    queryClient.invalidateQueries({ queryKey: ["open-jobs"] });
  };

  useEffect(() => base44.entities.ServiceRequest.subscribe(() => {
    queryClient.invalidateQueries({ queryKey: ["tech-jobs"] });
    queryClient.invalidateQueries({ queryKey: ["open-jobs"] });
  }), [queryClient]);

  if (userLoading || techLoading) return null;
  if (!isTechnician) return <Navigate to="/" replace />;

  return (
    <PullToRefresh queryKeys={[["tech-jobs"], ["open-jobs"]]}>
      <PageTitle eyebrow={t("tp_eyebrow")} title={t("nav_jobs")} subtitle={t("tp_subtitle")} />
      <section className="space-y-3">
        <h2 className="text-xs uppercase tracking-[0.2em] text-primary font-semibold">{t("new_requests")}</h2>
        {freshLoading ? (
          <div className="flex justify-center py-10"><Loader2 className="w-6 h-6 animate-spin text-primary" /></div>
        ) : openJobs.length === 0 ? (
          <p className="text-sm text-muted-foreground">{t("no_open")}</p>
        ) : (
          <div className="space-y-4">{openJobs.map((j) => <TechnicianJobCard key={j.id} job={j} technician={technician} onChanged={refresh} />)}</div>
        )}
      </section>
      <section className="space-y-3 mt-10">
        <h2 className="text-xs uppercase tracking-[0.2em] text-primary font-semibold">{t("my_jobs")}</h2>
        {isLoading ? (
          <div className="flex justify-center py-10"><Loader2 className="w-6 h-6 animate-spin text-primary" /></div>
        ) : mine.length === 0 ? (
          <p className="text-sm text-muted-foreground">{t("no_jobs")}</p>
        ) : (
          <div className="space-y-4">{mine.map((j) => <TechnicianJobCard key={j.id} job={j} technician={technician} onChanged={refresh} />)}</div>
        )}
      </section>
    </PullToRefresh>
  );
}