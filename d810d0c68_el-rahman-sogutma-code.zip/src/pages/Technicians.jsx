import React, { useState } from "react";
import { Navigate } from "react-router-dom";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Loader2, Mail, Phone, Trash2, UserPlus, Wrench } from "lucide-react";
import { base44 } from "@/api/base44Client";
import useCurrentUser from "@/hooks/useCurrentUser";
import { useLanguage } from "@/lib/i18n";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import PageTitle from "@/components/common/PageTitle";

export default function Technicians() {
  const { isAdmin, isLoading: userLoading } = useCurrentUser();
  const { t } = useLanguage();
  const queryClient = useQueryClient();
  const [form, setForm] = useState({ name: "", phone: "", email: "" });
  const [saving, setSaving] = useState(false);
  const { data: technicians = [], isLoading } = useQuery({
    queryKey: ["technicians"],
    queryFn: () => base44.entities.Technician.list("-created_date", 200),
    enabled: isAdmin,
  });

  if (userLoading) return null;
  if (!isAdmin) return <Navigate to="/" replace />;

  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));
  const valid = form.name.trim() && form.phone.trim() && form.email.trim();

  const add = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      await base44.users.inviteUser(form.email.trim(), "user");
    } catch {
      // hesap zaten varsa davet başarısız olabilir; kayıt yine de eklenir
    }
    await base44.entities.Technician.create({ ...form, email: form.email.trim() });
    setForm({ name: "", phone: "", email: "" });
    await queryClient.invalidateQueries({ queryKey: ["technicians"] });
    setSaving(false);
  };

  const remove = async (id) => {
    await base44.entities.Technician.delete(id);
    await queryClient.invalidateQueries({ queryKey: ["technicians"] });
  };

  return (
    <>
      <PageTitle eyebrow={t("admin_eyebrow")} title={t("techs")} subtitle={t("tech_page_subtitle")} />
      <form onSubmit={add} className="rounded-3xl border border-border bg-card p-5 space-y-3 mb-6">
        <p className="flex items-center gap-2 text-sm font-medium"><UserPlus className="w-4 h-4 text-primary" />{t("new_tech")}</p>
        <Input placeholder={t("name_ph")} value={form.name} onChange={set("name")} className="h-12" required />
        <Input type="tel" inputMode="tel" placeholder={t("phone_ph")} value={form.phone} onChange={set("phone")} className="h-12" required />
        <Input type="email" inputMode="email" placeholder={t("email_ph")} value={form.email} onChange={set("email")} className="h-12" required />
        <Button type="submit" disabled={!valid || saving} className="w-full h-12 rounded-full bg-gold-gradient text-black font-semibold hover:opacity-90">
          {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : t("add_tech")}
        </Button>
        <p className="text-xs text-muted-foreground">{t("tech_note")}</p>
      </form>
      {isLoading ? (
        <div className="flex justify-center py-16"><Loader2 className="w-6 h-6 animate-spin text-primary" /></div>
      ) : technicians.length === 0 ? (
        <p className="text-center text-muted-foreground py-16">{t("tech_empty")}</p>
      ) : (
        <div className="space-y-3">
          {technicians.map((tech) => (
            <div key={tech.id} className="flex items-center gap-4 rounded-3xl border border-border bg-card p-4">
              <div className="w-11 h-11 rounded-2xl bg-accent flex items-center justify-center text-primary shrink-0"><Wrench className="w-5 h-5" /></div>
              <div className="min-w-0 flex-1">
                <p className="font-medium truncate">{tech.name}</p>
                <div className="flex flex-wrap gap-x-4 text-xs text-muted-foreground mt-0.5">
                  <span className="flex items-center gap-1"><Phone className="w-3.5 h-3.5" />{tech.phone}</span>
                  <span className="flex items-center gap-1 truncate"><Mail className="w-3.5 h-3.5" />{tech.email}</span>
                </div>
              </div>
              <Button variant="ghost" size="icon" onClick={() => remove(tech.id)} className="text-destructive hover:text-destructive" aria-label={t("delete_tech")}>
                <Trash2 className="w-4 h-4" />
              </Button>
            </div>
          ))}
        </div>
      )}
    </>
  );
}