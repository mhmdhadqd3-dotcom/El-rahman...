import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Loader2, Send } from "lucide-react";
import { base44 } from "@/api/base44Client";
import useCurrentUser from "@/hooks/useCurrentUser";
import { useLanguage } from "@/lib/i18n";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import PageTitle from "@/components/common/PageTitle";
import FormSection from "@/components/booking/FormSection";
import ServicePicker from "@/components/booking/ServicePicker";
import DateTimePicker from "@/components/booking/DateTimePicker";
import PhotoUpload from "@/components/booking/PhotoUpload";
import LocationPicker from "@/components/booking/LocationPicker";

export default function NewRequest() {
  const { user } = useCurrentUser();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [form, setForm] = useState({ customer_name: "", customer_phone: "", service_type: "", appointment_date: "", appointment_time: "", description: "", photo_uri: "", address: "" });
  const [position, setPosition] = useState(null);
  const [saving, setSaving] = useState(false);
  const set = (k) => (v) => setForm((f) => ({ ...f, [k]: v }));
  const { t } = useLanguage();
  const { data: booked = [] } = useQuery({
    queryKey: ["booked-slots"],
    queryFn: () => base44.entities.ServiceRequest.list("-created_date", 500),
  });
  const takenSlots = booked
    .filter((r) => ["alindi", "onaylandi", "yolda"].includes(r.status) && r.appointment_date === form.appointment_date)
    .map((r) => r.appointment_time);

  const name = form.customer_name || user?.full_name || "";
  const valid = name && form.customer_phone && form.service_type && form.appointment_date && form.appointment_time;

  const submit = async (e) => {
    e.preventDefault();
    setSaving(true);
    await base44.entities.ServiceRequest.create({
      ...form, customer_name: name, status: "alindi",
      ...(position ? { latitude: position[0], longitude: position[1] } : {}),
    });
    await queryClient.invalidateQueries({ queryKey: ["my-requests"] });
    await queryClient.invalidateQueries({ queryKey: ["booked-slots"] });
    navigate("/");
  };

  return (
    <form onSubmit={submit} className="space-y-10">
      <PageTitle eyebrow={t("nr_eyebrow")} title={t("nav_new")} subtitle={t("nr_subtitle")} />
      <FormSection step={1} title={t("f1")}>
        <div className="grid sm:grid-cols-2 gap-3">
          <Input placeholder={t("name_ph")} value={name} onChange={(e) => set("customer_name")(e.target.value)} className="h-12" />
          <Input type="tel" inputMode="tel" placeholder={t("phone_ph")} value={form.customer_phone} onChange={(e) => set("customer_phone")(e.target.value)} className="h-12" />
        </div>
      </FormSection>
      <FormSection step={2} title={t("f2")}><ServicePicker value={form.service_type} onChange={set("service_type")} /></FormSection>
      <FormSection step={3} title={t("f3")}>
        <DateTimePicker date={form.appointment_date} time={form.appointment_time} onDate={set("appointment_date")} onTime={set("appointment_time")} takenSlots={takenSlots} />
      </FormSection>
      <FormSection step={4} title={t("f4")}>
        <Textarea rows={4} placeholder={t("desc_ph")} value={form.description} onChange={(e) => set("description")(e.target.value)} />
        <PhotoUpload value={form.photo_uri} onChange={set("photo_uri")} />
      </FormSection>
      <FormSection step={5} title={t("f5")}>
        <Input placeholder={t("addr_ph")} value={form.address} onChange={(e) => set("address")(e.target.value)} className="h-12" />
        <LocationPicker position={position} onChange={setPosition} />
      </FormSection>
      <Button type="submit" disabled={!valid || saving} className="w-full h-14 rounded-full text-base font-semibold bg-gold-gradient text-black hover:opacity-90">
        {saving ? <Loader2 className="w-5 h-5 animate-spin" /> : <><Send className="w-4 h-4 mr-2" />{t("submit")}</>}
      </Button>
    </form>
  );
}