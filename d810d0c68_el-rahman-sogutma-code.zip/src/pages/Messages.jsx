import React, { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ChevronLeft, Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import useCurrentUser from "@/hooks/useCurrentUser";
import { useLanguage } from "@/lib/i18n";
import PageTitle from "@/components/common/PageTitle";
import ChatThread from "@/components/messages/ChatThread";
import ConversationList from "@/components/messages/ConversationList";
import PullToRefresh from "@/components/common/PullToRefresh";

export default function Messages() {
  const { user, isAdmin } = useCurrentUser();
  const { t } = useLanguage();
  const queryClient = useQueryClient();
  const [thread, setThread] = useState(() => {
    const c = new URLSearchParams(window.location.search).get("c");
    return c ? { id: c, name: "" } : null;
  });
  const { data: all = [], isLoading } = useQuery({
    queryKey: ["messages", "all"],
    queryFn: () => base44.entities.Message.list("-created_date", 500),
    enabled: isAdmin,
  });

  useEffect(() => base44.entities.Message.subscribe(() => {
    queryClient.invalidateQueries({ queryKey: ["messages"] });
  }), [queryClient]);

  if (!user) return <div className="flex justify-center py-20"><Loader2 className="w-6 h-6 animate-spin text-primary" /></div>;

  if (!isAdmin) {
    return (
      <PullToRefresh queryKeys={[["messages"]]}>
        <PageTitle eyebrow={t("msg_support_eyebrow")} title={t("msg_title")} subtitle={t("msg_subtitle_customer")} />
        <ChatThread customerId={user.id} customerName={user.full_name || user.email} role="customer" />
      </PullToRefresh>
    );
  }

  const threadName = thread && (thread.name || all.find((m) => m.customer_id === thread.id)?.customer_name || t("customer"));

  return (
    <PullToRefresh queryKeys={[["messages"]]}>
      <PageTitle eyebrow={t("admin_eyebrow")} title={t("msg_title")} subtitle={t("msg_admin_subtitle")} />
      <div className="grid md:grid-cols-[260px_1fr] gap-4">
        <div className={thread ? "hidden md:block" : ""}>
          {isLoading ? <Loader2 className="w-5 h-5 animate-spin text-primary mx-auto" /> :
            <ConversationList messages={all} selected={thread?.id} onSelect={(id, name) => setThread({ id, name })} />}
        </div>
        {thread ? (
          <div className="space-y-3">
            <button onClick={() => setThread(null)} className="md:hidden flex items-center text-sm text-primary"><ChevronLeft className="w-4 h-4 rtl:rotate-180" />{t("conversations")}</button>
            <p className="font-heading text-2xl">{threadName}</p>
            <ChatThread key={thread.id} customerId={thread.id} customerName={threadName} role="admin" />
          </div>
        ) : (
          <p className="hidden md:flex items-center justify-center text-muted-foreground rounded-3xl border border-dashed border-border">{t("select_conversation")}</p>
        )}
      </div>
    </PullToRefresh>
  );
}