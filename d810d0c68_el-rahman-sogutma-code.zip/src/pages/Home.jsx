import React, { useEffect } from "react";
import { Link, Navigate } from "react-router-dom";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { CalendarPlus, Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import useCurrentUser from "@/hooks/useCurrentUser";
import useTechnician from "@/hooks/useTechnician";
import { useLanguage } from "@/lib/i18n";
import PageTitle from "@/components/common/PageTitle";
import PullToRefresh from "@/components/common/PullToRefresh";
import CustomerRequestCard from "@/components/requests/CustomerRequestCard";
import { Button } from "@/components/ui/button";

const REFRESH_KEYS = [["my-requests"]];

export default function Home() {
  const { user, isAdmin } = useCurrentUser();
  const { isTechnician, isLoading: isLoadingTech } = useTechnician(user);
  const { t } = useLanguage();
  const queryClient = useQueryClient();
  const { data: requests = [], isLoading } = useQuery({
    queryKey: ["my-requests", user?.id],
    queryFn: () => base44.entities.ServiceRequest.filter({ created_by_id: user.id }, "-created_date", 50),
    enabled: !!user,
  });

  useEffect(() => base44.entities.ServiceRequest.subscribe(() => {
    queryClient.invalidateQueries({ queryKey: ["my-requests"] });
  }), [queryClient]);

  // Technicians are redirected to their jobs panel
  if (!isLoadingTech && isTechnician && !isAdmin) return <Navigate to="/teknisyen" replace />;

  return (
    <PullToRefresh queryKeys={REFRESH_KEYS}>
      <PageTitle
        eyebrow={t("home_eyebrow")}
        title={t("nav_requests")}
        subtitle={t("home_subtitle")}
      />
      {isLoading || !user ? (
        <div className="flex justify-center py-20"><Loader2 className="w-6 h-6 animate-spin text-primary" /></div>
      ) : requests.length === 0 ? (
        <div className="rounded-3xl border border-dashed border-border p-10 text-center">
          <p className="font-heading text-2xl">{t("home_empty_title")}</p>
          <p className="text-muted-foreground text-sm mt-2 mb-6">{t("home_empty_text")}</p>
          <Button asChild className="rounded-full h-11 px-6"><Link to="/randevu"><CalendarPlus className="w-4 h-4 mr-2" />{t("nav_new")}</Link></Button>
        </div>
      ) : (
        <div className="space-y-4">
          {requests.map((r, i) => <CustomerRequestCard key={r.id} request={r} index={i} />)}
        </div>
      )}
    </PullToRefresh>
  );
}