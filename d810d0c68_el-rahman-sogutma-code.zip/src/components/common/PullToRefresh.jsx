import React, { useCallback } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { ArrowDown, Loader2 } from "lucide-react";
import usePullToRefresh from "@/hooks/usePullToRefresh";

export default function PullToRefresh({ queryKeys, children }) {
  const queryClient = useQueryClient();
  const onRefresh = useCallback(
    () => Promise.all(queryKeys.map((k) => queryClient.invalidateQueries({ queryKey: k }))),
    [queryClient, queryKeys]
  );
  const { pull, refreshing, ready } = usePullToRefresh(onRefresh);
  const height = refreshing ? 48 : pull;

  return (
    <div>
      <div
        className="flex items-center justify-center overflow-hidden text-primary transition-[height] duration-200"
        style={{ height }}
      >
        {refreshing ? (
          <Loader2 className="w-5 h-5 animate-spin" />
        ) : (
          <ArrowDown className={`w-5 h-5 transition-transform ${ready ? "rotate-180" : ""}`} />
        )}
      </div>
      {children}
    </div>
  );
}