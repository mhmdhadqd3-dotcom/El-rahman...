import React from "react";

export default function PageTitle({ eyebrow, title, subtitle, action }) {
  return (
    <div className="flex items-end justify-between gap-4 mb-8">
      <div>
        {eyebrow && <p className="text-xs tracking-[0.3em] uppercase text-primary mb-2">{eyebrow}</p>}
        <h1 className="font-heading text-4xl sm:text-5xl font-semibold leading-[1.05]">{title}</h1>
        {subtitle && <p className="text-muted-foreground mt-3 max-w-md">{subtitle}</p>}
      </div>
      {action}
    </div>
  );
}