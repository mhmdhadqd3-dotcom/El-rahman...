import React from "react";

export default function FormSection({ step, title, children }) {
  return (
    <section className="space-y-4">
      <div className="flex items-baseline gap-3">
        <span className="font-heading text-2xl text-primary">{String(step).padStart(2, "0")}</span>
        <h2 className="text-sm font-semibold tracking-wide uppercase">{title}</h2>
      </div>
      {children}
    </section>
  );
}