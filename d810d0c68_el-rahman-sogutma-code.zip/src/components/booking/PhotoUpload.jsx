import React, { useState } from "react";
import { ImagePlus, Loader2, X } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useLanguage } from "@/lib/i18n";

export default function PhotoUpload({ value, onChange }) {
  const { t } = useLanguage();
  const [preview, setPreview] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleFile = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setLoading(true);
    setPreview(URL.createObjectURL(file));
    const { file_uri } = await base44.integrations.Core.UploadPrivateFile({ file });
    onChange(file_uri);
    setLoading(false);
  };

  if (preview) {
    return (
      <div className="relative w-full h-44 rounded-2xl overflow-hidden border border-border">
        <img src={preview} alt="" className="w-full h-full object-cover" />
        {loading && <div className="absolute inset-0 bg-black/60 flex items-center justify-center"><Loader2 className="w-6 h-6 animate-spin text-primary" /></div>}
        {!loading && value && (
          <button type="button" onClick={() => { setPreview(null); onChange(""); }} className="absolute top-2 right-2 w-8 h-8 rounded-full bg-black/70 flex items-center justify-center">
            <X className="w-4 h-4" />
          </button>
        )}
      </div>
    );
  }

  return (
    <label className="flex flex-col items-center justify-center gap-2 h-32 rounded-2xl border border-dashed border-border bg-card cursor-pointer hover:border-primary/50 transition-colors">
      <ImagePlus className="w-6 h-6 text-primary" />
      <span className="text-sm text-muted-foreground">{t("photo_add")}</span>
      <input type="file" accept="image/*" className="hidden" onChange={handleFile} />
    </label>
  );
}