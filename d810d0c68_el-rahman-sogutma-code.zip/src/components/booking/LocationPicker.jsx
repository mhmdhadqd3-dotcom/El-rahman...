import React, { useEffect } from "react";
import { MapContainer, TileLayer, CircleMarker, useMap, useMapEvents } from "react-leaflet";
import "leaflet/dist/leaflet.css";
import { LocateFixed } from "lucide-react";
import { SHOP } from "@/lib/serviceConfig";
import { useLanguage } from "@/lib/i18n";

function ClickHandler({ onPick }) {
  useMapEvents({ click: (e) => onPick([e.latlng.lat, e.latlng.lng]) });
  return null;
}

function MapAdjust({ position }) {
  const map = useMap();
  useEffect(() => {
    const t = setTimeout(() => map.invalidateSize(), 150);
    if (position) map.flyTo(position, 16);
    return () => clearTimeout(t);
  }, [position, map]);
  return null;
}

export default function LocationPicker({ position, onChange }) {
  const { t } = useLanguage();
  const locate = () => {
    navigator.geolocation?.getCurrentPosition((p) => onChange([p.coords.latitude, p.coords.longitude]));
  };
  return (
    <div className="relative rounded-2xl overflow-hidden border border-border h-64 z-0">
      <MapContainer center={SHOP.center} zoom={13} className="w-full h-full">
        <TileLayer url="https://tile.openstreetmap.org/{z}/{x}/{y}.png" attribution="&copy; OpenStreetMap katkıcıları" />
        <ClickHandler onPick={onChange} />
        <MapAdjust position={position} />
        {position && <CircleMarker center={position} radius={11} pathOptions={{ color: "#d6ae4b", fillColor: "#d6ae4b", fillOpacity: 0.8, weight: 3 }} />}
      </MapContainer>
      <button type="button" onClick={locate} className="absolute bottom-3 right-3 z-[500] flex items-center gap-1.5 rounded-full bg-primary text-primary-foreground px-3.5 py-2 text-xs font-semibold shadow-lg">
        <LocateFixed className="w-4 h-4" /> {t("locate")}
      </button>
      {!position && <div className="absolute top-3 left-3 z-[500] rounded-full bg-black/75 px-3 py-1.5 text-xs">{t("map_hint")}</div>}
    </div>
  );
}