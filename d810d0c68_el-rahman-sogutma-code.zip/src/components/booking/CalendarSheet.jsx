import React, { useEffect, useMemo, useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useLanguage } from "@/lib/i18n";

const toISO = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
const fromISO = (s) => {
  const [y, m, day] = s.split("-").map(Number);
  return new Date(y, m - 1, day);
};

export default function CalendarSheet({ open, onOpenChange, value, onSelect }) {
  const { t, locale } = useLanguage();
  const [view, setView] = useState(() => {
    const d = value ? fromISO(value) : new Date();
    return { y: d.getFullYear(), m: d.getMonth() };
  });

  useEffect(() => {
    if (open) {
      const d = value ? fromISO(value) : new Date();
      setView({ y: d.getFullYear(), m: d.getMonth() });
    }
  }, [open]);

  const today = useMemo(() => { const d = new Date(); d.setHours(0, 0, 0, 0); return d; }, []);
  // Jan 1 2024 was a Monday
  const weekdays = useMemo(
    () => Array.from({ length: 7 }, (_, i) => new Date(2024, 0, 1 + i).toLocaleDateString(locale, { weekday: "narrow" })),
    [locale]
  );
  const monthName = new Date(view.y, view.m, 1).toLocaleDateString(locale, { month: "long", year: "numeric" });
  const offset = (new Date(view.y, view.m, 1).getDay() + 6) % 7;
  const daysInMonth = new Date(view.y, view.m + 1, 0).getDate();
  const canGoPrev = view.y > today.getFullYear() || (view.y === today.getFullYear() && view.m > today.getMonth());

  const step = (delta) => setView((v) => {
    const m = v.m + delta;
    return m < 0 ? { y: v.y - 1, m: 11 } : m > 11 ? { y: v.y + 1, m: 0 } : { y: v.y, m };
  });

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="rounded-3xl max-w-sm">
        <DialogHeader>
          <DialogTitle className="font-heading text-2xl">{t("pick_date")}</DialogTitle>
        </DialogHeader>
        <div className="flex items-center justify-between mb-3">
          <button type="button" disabled={!canGoPrev} onClick={() => step(-1)}
            className="w-11 h-11 rounded-full flex items-center justify-center hover:bg-accent disabled:opacity-30" aria-label="Önceki ay">
            <ChevronLeft className="w-5 h-5 rtl:rotate-180" />
          </button>
          <p className="text-sm font-medium capitalize">{monthName}</p>
          <button type="button" onClick={() => step(1)}
            className="w-11 h-11 rounded-full flex items-center justify-center hover:bg-accent" aria-label="Sonraki ay">
            <ChevronRight className="w-5 h-5 rtl:rotate-180" />
          </button>
        </div>
        <div className="grid grid-cols-7 gap-1 mb-1">
          {weekdays.map((w, i) => (
            <span key={i} className="text-center text-xs text-muted-foreground py-1">{w}</span>
          ))}
        </div>
        <div className="grid grid-cols-7 gap-1">
          {Array.from({ length: offset }, (_, i) => <span key={`empty-${i}`} />)}
          {Array.from({ length: daysInMonth }, (_, i) => {
            const day = i + 1;
            const d = new Date(view.y, view.m, day);
            const disabled = d < today;
            const selected = value === toISO(d);
            return (
              <button key={day} type="button" disabled={disabled} onClick={() => { onSelect(toISO(d)); onOpenChange(false); }}
                className={`h-11 rounded-full text-sm transition-colors ${selected ? "bg-primary text-primary-foreground font-semibold" : disabled ? "text-muted-foreground/40" : "text-foreground hover:bg-accent"}`}>
                {day}
              </button>
            );
          })}
        </div>
      </DialogContent>
    </Dialog>
  );
}