import React from "react";
import { SERVICES } from "@/lib/serviceConfig";
import { useLanguage } from "@/lib/i18n";

export default function ServicePicker({ value, onChange }) {
  const { t } = useLanguage();
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
      {SERVICES.map(({ id, icon: Icon }) => {
        const active = value === id;
        return (
          <button key={id} type="button" onClick={() => onChange(id)}
            className={`rounded-2xl border p-4 text-left transition-all duration-300 ${active ? "border-primary bg-accent shadow-[0_0_0_1px_hsl(var(--primary))]" : "border-border bg-card hover:border-primary/40"}`}>
            <Icon className={`w-6 h-6 mb-3 ${active ? "text-primary" : "text-muted-foreground"}`} />
            <span className="text-sm font-medium leading-snug block">{t(`service_${id}`)}</span>
          </button>
        );
      })}
    </div>
  );
}