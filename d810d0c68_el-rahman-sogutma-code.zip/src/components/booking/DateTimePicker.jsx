import React, { useState } from "react";
import { CalendarDays } from "lucide-react";
import { TIME_SLOTS } from "@/lib/serviceConfig";
import { useLanguage } from "@/lib/i18n";
import CalendarSheet from "@/components/booking/CalendarSheet";

const fromISO = (s) => {
  const [y, m, day] = s.split("-").map(Number);
  return new Date(y, m - 1, day);
};

export default function DateTimePicker({ date, time, onDate, onTime, takenSlots = [] }) {
  const { t, locale } = useLanguage();
  const [open, setOpen] = useState(false);
  return (
    <div className="space-y-4">
      <button type="button" onClick={() => setOpen(true)}
        className="h-12 w-full rounded-xl border border-input bg-transparent px-4 text-sm flex items-center gap-2 text-left transition-colors hover:border-primary/40">
        <CalendarDays className="w-4 h-4 shrink-0 text-primary" />
        <span className={date ? "" : "text-muted-foreground"}>
          {date ? fromISO(date).toLocaleDateString(locale, { day: "numeric", month: "long", year: "numeric" }) : t("pick_date")}
        </span>
      </button>
      <CalendarSheet open={open} onOpenChange={setOpen} value={date} onSelect={onDate} />
      <div className="grid grid-cols-5 gap-2">
        {TIME_SLOTS.map((t) => {
          const taken = takenSlots.includes(t);
          return (
            <button key={t} type="button" disabled={taken} onClick={() => onTime(t)}
              className={`h-11 rounded-xl text-sm border transition-colors ${time === t ? "bg-primary text-primary-foreground border-primary font-semibold" : taken ? "border-border bg-muted/30 text-muted-foreground line-through opacity-50 cursor-not-allowed" : "border-border bg-card hover:border-primary/40"}`}>
              {t}
            </button>
          );
        })}
      </div>
    </div>
  );
}