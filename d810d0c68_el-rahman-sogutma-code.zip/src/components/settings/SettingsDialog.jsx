import React from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { LogOut, Moon, Sun } from "lucide-react";
import { useTheme } from "next-themes";
import { base44 } from "@/api/base44Client";
import useCurrentUser from "@/hooks/useCurrentUser";
import { useLanguage, LANGS } from "@/lib/i18n";
import DeleteAccountButton from "@/components/settings/DeleteAccountButton";

export default function SettingsDialog({ open, onOpenChange }) {
  const { user } = useCurrentUser();
  const { t, lang, setLang } = useLanguage();
  const { theme, setTheme } = useTheme();
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-sm rounded-3xl">
        <DialogHeader>
          <DialogTitle className="font-heading text-2xl">{t("settings")}</DialogTitle>
        </DialogHeader>
        <div className="rounded-2xl bg-muted p-4">
          <p className="font-medium">{user?.full_name || t("my_account")}</p>
          <p className="text-sm text-muted-foreground break-all">{user?.email}</p>
        </div>
        <div className="rounded-2xl bg-muted p-4">
          <p className="text-sm font-medium mb-3">{t("language")}</p>
          <div className="grid grid-cols-3 gap-2">
            {LANGS.map((l) => (
              <button key={l.code} type="button" onClick={() => setLang(l.code)}
                className={`h-11 rounded-xl text-sm font-medium border transition-colors ${lang === l.code ? "border-primary bg-accent text-primary" : "border-border bg-card hover:border-primary/40"}`}>
                {l.label}
              </button>
            ))}
          </div>
        </div>
        <div className="rounded-2xl bg-muted p-4">
          <p className="text-sm font-medium mb-3">{t("theme")}</p>
          <div className="grid grid-cols-2 gap-2">
            <button type="button" onClick={() => setTheme("dark")}
              className={`h-11 rounded-xl text-sm font-medium border transition-colors flex items-center justify-center gap-2 ${theme !== "light" ? "border-primary bg-accent text-primary" : "border-border bg-card hover:border-primary/40"}`}>
              <Moon className="w-4 h-4" /> {t("theme_dark")}
            </button>
            <button type="button" onClick={() => setTheme("light")}
              className={`h-11 rounded-xl text-sm font-medium border transition-colors flex items-center justify-center gap-2 ${theme === "light" ? "border-primary bg-accent text-primary" : "border-border bg-card hover:border-primary/40"}`}>
              <Sun className="w-4 h-4" /> {t("theme_light")}
            </button>
          </div>
        </div>
        <Button variant="outline" className="w-full h-11" onClick={() => base44.auth.logout("/login")}>
          <LogOut className="w-4 h-4 mr-2" /> {t("logout")}
        </Button>
        <DeleteAccountButton user={user} />
      </DialogContent>
    </Dialog>
  );
}