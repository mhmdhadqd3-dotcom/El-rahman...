import React, { useState } from "react";
import { Trash2, Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useLanguage } from "@/lib/i18n";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export default function DeleteAccountButton({ user }) {
  const { t } = useLanguage();
  const [loading, setLoading] = useState(false);

  const handleDelete = async (e) => {
    e.preventDefault();
    setLoading(true);
    await base44.entities.ServiceRequest.deleteMany({ created_by_id: user.id });
    await base44.entities.Message.deleteMany({ customer_id: user.id });
    try {
      await base44.entities.User.delete(user.id);
    } catch (_e) {
      // Account record removal may not be permitted from the client; data deletion + logout still apply
    }
    base44.auth.logout("/login");
  };

  return (
    <AlertDialog>
      <AlertDialogTrigger asChild>
        <button className="w-full flex items-center justify-center gap-2 h-11 rounded-md text-sm text-destructive hover:bg-destructive/10 transition-colors">
          <Trash2 className="w-4 h-4" /> {t("del_account")}
        </button>
      </AlertDialogTrigger>
      <AlertDialogContent className="rounded-3xl max-w-sm">
        <AlertDialogHeader>
          <AlertDialogTitle>{t("del_title")}</AlertDialogTitle>
          <AlertDialogDescription>
            {t("del_desc")}
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel disabled={loading}>{t("cancel_back")}</AlertDialogCancel>
          <AlertDialogAction onClick={handleDelete} disabled={loading || !user} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
            {loading && <Loader2 className="w-4 h-4 mr-2 animate-spin" />} {t("del_yes")}
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}