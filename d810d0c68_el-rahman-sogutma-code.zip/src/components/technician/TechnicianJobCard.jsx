import React from "react";
import { CalendarDays, CheckCheck, Clock, MapPin, Navigation, Phone, Eye, EyeOff, Wrench } from "lucide-react";
import { serviceById, formatDate } from "@/lib/serviceConfig";
import { useLanguage } from "@/lib/i18n";
import useRequestUpdate from "@/hooks/useRequestUpdate";
import PhotoViewButton from "@/components/admin/PhotoViewButton";
import IbanCard from "@/components/requests/IbanCard";

const btn = "flex items-center justify-center gap-1.5 h-11 rounded-xl text-xs font-medium border transition-colors";
const ghost = `${btn} border-border bg-muted/40 hover:border-primary/50`;

export default function TechnicianJobCard({ job, technician }) {
  const { t, locale } = useLanguage();
  const service = serviceById(job.service_type);
  const { mutate: rawUpdate } = useRequestUpdate();
  const update = (data) => rawUpdate({ id: job.id, data });
  const claim = technician ? { technician: technician.name, technician_id: technician.id } : {};
  const openLocation = () => {
    const q = job.latitude ? `${job.latitude},${job.longitude}` : encodeURIComponent(job.address || "");
    window.open(`https://www.google.com/maps/dir/?api=1&destination=${q}`, "_blank");
  };
  const s = job.status;

  return (
    <div className="rounded-3xl border border-border bg-card p-5 space-y-4">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="font-heading text-2xl font-semibold leading-tight">{job.customer_name}</p>
          <p className="text-sm text-primary mt-0.5 flex items-center gap-1.5"><Wrench className="w-3.5 h-3.5" />{t(`service_${service.id}`)}</p>
        </div>
        <span className="shrink-0 rounded-full bg-accent text-accent-foreground px-3 py-1 text-sm font-medium">{t(`status_${s}`)}</span>
      </div>
      <div className="grid sm:grid-cols-2 gap-2 text-sm text-muted-foreground">
        <span className="flex items-center gap-2"><Phone className="w-4 h-4" />{job.customer_phone}</span>
        <span className="flex items-center gap-2"><CalendarDays className="w-4 h-4" />{formatDate(job.appointment_date, locale)}</span>
        <span className="flex items-center gap-2"><Clock className="w-4 h-4" />{job.appointment_time}</span>
        {job.address && <span className="flex items-start gap-2 sm:col-span-2"><MapPin className="w-4 h-4 mt-0.5 shrink-0" />{job.address}</span>}
      </div>
      {job.description && <p className="text-sm border-l-2 border-primary/50 pl-3">{job.description}</p>}
      {job.photo_uri && <PhotoViewButton uri={job.photo_uri} />}
      {job.iban_visible && <IbanCard />}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
        {(s === "alindi" || s === "onaylandi") && (
          <button onClick={() => update({ status: "yolda", ...claim })} className={`${btn} bg-primary text-primary-foreground border-primary`}>
            <CheckCheck className="w-4 h-4" />{t("accept")}
          </button>
        )}
        {s === "yolda" && (
          <>
            <button onClick={openLocation} className={ghost}><Navigation className="w-4 h-4" />{t("directions")}</button>
            <button onClick={() => update({ status: "tamamlandi" })} className={`${btn} bg-primary text-primary-foreground border-primary`}>
              <CheckCheck className="w-4 h-4" />{t("done")}
            </button>
          </>
        )}
        <a href={`tel:${job.customer_phone}`} className={ghost}><Phone className="w-4 h-4" />{t("call")}</a>
        <button onClick={() => update({ iban_visible: !job.iban_visible })}
          className={job.iban_visible ? `${btn} border-primary text-primary bg-accent` : ghost}>
          {job.iban_visible ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
          {job.iban_visible ? t("iban_hide") : t("iban_show")}
        </button>
      </div>
    </div>
  );
}