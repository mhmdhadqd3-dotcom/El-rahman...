import React, { createContext, useContext, useEffect, useRef } from "react";
import { useLocation, useNavigate } from "react-router-dom";

const TAB_ROOTS = ["/", "/randevu", "/mesajlar", "/teknisyen", "/panel"];

export const tabOf = (pathname) => {
  const root = "/" + (pathname.split("/")[1] || "");
  return TAB_ROOTS.includes(root) ? root : null;
};

const TabStackContext = createContext(null);

/**
 * Per-tab navigation stack preservation: remembers each bottom tab's last
 * visited route and scroll offset, restores them when the tab is re-entered,
 * and resets to the root route when the active tab is re-selected.
 */
export function TabStackProvider({ children }) {
  const { pathname } = useLocation();
  const navigate = useNavigate();
  const stacks = useRef({}); // tabRoot -> { route, scroll }
  const scrollRef = useRef(0);
  const activeTabRef = useRef(null);
  const pathnameRef = useRef(pathname);

  useEffect(() => {
    const onScroll = () => { scrollRef.current = window.scrollY; };
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    const prevTab = activeTabRef.current;
    const prevPath = pathnameRef.current;
    const tab = tabOf(pathname);
    if (prevTab && prevTab !== tab) {
      // Leaving a tab: commit its last route + scroll position
      stacks.current[prevTab] = { route: prevPath, scroll: scrollRef.current };
    }
    if (tab && prevTab !== tab) {
      // Entering a tab: restore its saved scroll if we landed on its saved route
      const entry = stacks.current[tab];
      if (entry && entry.route === pathname && entry.scroll > 0) {
        requestAnimationFrame(() => window.scrollTo({ top: entry.scroll, behavior: "instant" }));
      }
    }
    if (tab) activeTabRef.current = tab;
    pathnameRef.current = pathname;
  }, [pathname]);

  const switchTab = (tabRoot) => {
    const currentTab = activeTabRef.current;
    if (currentTab === tabRoot) {
      // Re-selecting the active tab resets it to its root route
      stacks.current[tabRoot] = { route: tabRoot, scroll: 0 };
      if (pathnameRef.current !== tabRoot) navigate(tabRoot);
      else window.scrollTo({ top: 0, behavior: "instant" });
    } else {
      if (currentTab) {
        stacks.current[currentTab] = { route: pathnameRef.current, scroll: scrollRef.current };
      }
      const entry = stacks.current[tabRoot];
      navigate(entry?.route || tabRoot);
    }
  };

  return (
    <TabStackContext.Provider value={{ activeTab: tabOf(pathname), switchTab }}>
      {children}
    </TabStackContext.Provider>
  );
}

export const useTabStack = () => useContext(TabStackContext);