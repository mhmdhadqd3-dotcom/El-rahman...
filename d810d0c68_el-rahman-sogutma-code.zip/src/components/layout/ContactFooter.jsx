import React from "react";
import { Link } from "react-router-dom";
import { Phone, MapPin, MessageCircle } from "lucide-react";
import { SHOP } from "@/lib/serviceConfig";
import { useLanguage } from "@/lib/i18n";

export default function ContactFooter() {
  const { t } = useLanguage();
  return (
    <footer className="border-t border-border mt-10">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-10 space-y-6">
        <div>
          <p className="text-xs tracking-[0.3em] uppercase text-primary">{t("contact")}</p>
          <h2 className="font-heading text-3xl font-semibold mt-1">{SHOP.name}</h2>
        </div>
        <div className="grid sm:grid-cols-3 gap-3">
          {SHOP.phones.map((p) => (
            <a key={p.tel} href={`tel:${p.tel}`} className="flex items-center gap-3 rounded-2xl border border-border bg-card px-4 py-3.5 hover:border-primary/50 transition-colors">
              <Phone className="w-4 h-4 text-primary" />
              <span className="text-sm font-medium">{p.display}</span>
            </a>
          ))}
          <Link to="/mesajlar" className="flex items-center gap-3 rounded-2xl bg-primary text-primary-foreground px-4 py-3.5 hover:opacity-90 transition-opacity">
            <MessageCircle className="w-4 h-4" />
            <span className="text-sm font-semibold">{t("send_msg")}</span>
          </Link>
        </div>
        <a href={SHOP.mapUrl} target="_blank" rel="noreferrer" className="flex items-start gap-3 text-sm text-muted-foreground hover:text-primary transition-colors">
          <MapPin className="w-4 h-4 mt-0.5 text-primary shrink-0" />
          {SHOP.address}
        </a>
      </div>
    </footer>
  );
}