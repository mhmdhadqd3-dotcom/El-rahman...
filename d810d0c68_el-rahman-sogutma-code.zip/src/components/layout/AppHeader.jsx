import React, { useState } from "react";
import { Link, NavLink, useLocation, useNavigate } from "react-router-dom";
import { ChevronLeft, Settings } from "lucide-react";
import useCurrentUser from "@/hooks/useCurrentUser";
import useTechnician from "@/hooks/useTechnician";
import { Image } from "@/components/ui/image";
import { SHOP } from "@/lib/serviceConfig";
import { useLanguage } from "@/lib/i18n";
import { getNavItems } from "@/components/layout/navItems";
import SettingsDialog from "@/components/settings/SettingsDialog";

export default function AppHeader() {
  const { pathname } = useLocation();
  const navigate = useNavigate();
  const { user, isAdmin } = useCurrentUser();
  const { isTechnician } = useTechnician(user);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const { t } = useLanguage();
  const isChild = pathname !== "/";

  return (
    <header className="sticky top-0 z-40 pt-safe bg-background/85 backdrop-blur-xl border-b border-border">
      <div className="max-w-5xl mx-auto h-16 px-4 sm:px-6 flex items-center gap-3">
        {isChild && (
          <button onClick={() => navigate(-1)} className="-ml-1 flex items-center text-sm text-primary" aria-label="Geri">
            <ChevronLeft className="w-5 h-5 rtl:rotate-180" /> {t("back")}
          </button>
        )}
        <Link to="/" className={`flex items-center gap-2.5 ${isChild ? "hidden md:flex" : "flex"}`}>
          <Image src={SHOP.logoUrl} alt="El Rahman Soğutma" className="w-10 h-10 rounded-xl border border-primary/30" fittingType="fill" />
          <div className="leading-none">
            <p className="font-heading text-xl font-semibold text-gold-gradient">El Rahman</p>
            <p className="text-xs tracking-[0.3em] uppercase text-muted-foreground mt-0.5">Soğutma</p>
          </div>
        </Link>
        <nav className="hidden md:flex items-center gap-1 ml-auto">
          {getNavItems(isAdmin, isTechnician).map((item) => (
            <NavLink key={item.to} to={item.to} end
              className={({ isActive }) => `px-4 py-2 rounded-full text-sm transition-colors ${isActive ? "bg-accent text-primary" : "text-muted-foreground hover:text-foreground"}`}>
              {t(item.labelKey)}
            </NavLink>
          ))}
        </nav>
        <button onClick={() => setSettingsOpen(true)} className="ml-auto md:ml-2 w-11 h-11 rounded-full flex items-center justify-center text-muted-foreground hover:text-primary hover:bg-accent transition-colors" aria-label="Ayarlar">
          <Settings className="w-5 h-5" />
        </button>
      </div>
      <SettingsDialog open={settingsOpen} onOpenChange={setSettingsOpen} />
    </header>
  );
}