import React from "react";
import useCurrentUser from "@/hooks/useCurrentUser";
import useTechnician from "@/hooks/useTechnician";
import { getNavItems } from "@/components/layout/navItems";
import { useLanguage } from "@/lib/i18n";
import { useTabStack } from "@/components/layout/TabStackContext";

export default function BottomTabBar() {
  const { user, isAdmin } = useCurrentUser();
  const { isTechnician } = useTechnician(user);
  const { t } = useLanguage();
  const { activeTab, switchTab } = useTabStack();
  return (
    <nav className="md:hidden fixed bottom-0 inset-x-0 z-40 bg-background/90 backdrop-blur-xl border-t border-border pb-safe">
      <div className="flex h-[4.5rem]">
        {getNavItems(isAdmin, isTechnician).map(({ to, labelKey, icon: Icon }) => {
          const isActive = activeTab === to;
          return (
            <button key={to} type="button" onClick={() => switchTab(to)} aria-current={isActive ? "page" : undefined}
              className={`flex-1 flex flex-col items-center justify-center gap-1 text-xs transition-colors ${isActive ? "text-primary" : "text-muted-foreground"}`}>
              <span className={`w-12 h-7 rounded-full flex items-center justify-center transition-colors ${isActive ? "bg-accent" : ""}`}>
                <Icon className="w-5 h-5" />
              </span>
              {t(labelKey)}
            </button>
          );
        })}
      </div>
    </nav>
  );
}