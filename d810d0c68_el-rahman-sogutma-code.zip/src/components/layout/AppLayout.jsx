import React from "react";
import { Outlet, useLocation, useNavigationType } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";
import AppHeader from "@/components/layout/AppHeader";
import BottomTabBar from "@/components/layout/BottomTabBar";
import ContactFooter from "@/components/layout/ContactFooter";
import { TabStackProvider } from "@/components/layout/TabStackContext";

export default function AppLayout() {
  const location = useLocation();
  const navType = useNavigationType();
  const isBack = navType === "POP";
  const enterX = isBack ? -20 : 20;
  return (
    <TabStackProvider>
      <div className="min-h-screen flex flex-col bg-background pb-[calc(4.5rem+env(safe-area-inset-bottom,0px))] md:pb-safe">
        <AppHeader />
        <main className="flex-1 w-full max-w-3xl mx-auto px-4 sm:px-6 py-6 sm:py-10">
          <AnimatePresence mode="wait" initial={false}>
            <motion.div
              key={location.pathname}
              initial={{ opacity: 0, x: enterX }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -enterX }}
              transition={{ duration: 0.22, ease: "easeOut" }}
            >
              <Outlet />
            </motion.div>
          </AnimatePresence>
        </main>
        <ContactFooter />
        <BottomTabBar />
      </div>
    </TabStackProvider>
  );
}