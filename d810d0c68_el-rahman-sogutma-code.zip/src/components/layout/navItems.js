import { ClipboardList, CalendarPlus, MessageCircle, ShieldCheck, Wrench } from "lucide-react";

export const getNavItems = (isAdmin, isTechnician) => {
  const items = [
    { to: "/", labelKey: "nav_requests", icon: ClipboardList },
    { to: "/randevu", labelKey: "nav_new", icon: CalendarPlus },
    { to: "/mesajlar", labelKey: "nav_messages", icon: MessageCircle },
    ...(isTechnician ? [{ to: "/teknisyen", labelKey: "nav_jobs", icon: Wrench }] : []),
    ...(isAdmin ? [{ to: "/panel", labelKey: "nav_admin", icon: ShieldCheck }] : []),
  ];
  // Technicians don't see the customer request list or new booking
  return isTechnician && !isAdmin ? items.filter((i) => i.to !== "/" && i.to !== "/randevu") : items;
};