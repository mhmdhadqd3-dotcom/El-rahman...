import React from "react";
import { motion } from "framer-motion";
import { CalendarDays, Clock, UserCog, X } from "lucide-react";
import { serviceById, formatDate } from "@/lib/serviceConfig";
import useRequestUpdate from "@/hooks/useRequestUpdate";
import { useLanguage } from "@/lib/i18n";
import StatusTracker from "@/components/requests/StatusTracker";
import IbanCard from "@/components/requests/IbanCard";
import {
  AlertDialog, AlertDialogTrigger, AlertDialogContent, AlertDialogHeader,
  AlertDialogTitle, AlertDialogDescription, AlertDialogFooter, AlertDialogCancel, AlertDialogAction,
} from "@/components/ui/alert-dialog";

export default function CustomerRequestCard({ request, index }) {
  const { t, locale } = useLanguage();
  const { mutate: cancelRequest, isPending: busy } = useRequestUpdate();
  const service = serviceById(request.service_type);
  const Icon = service.icon;
  const cancellable = ["alindi", "onaylandi"].includes(request.status);

  const cancel = () => cancelRequest({ id: request.id, data: { status: "iptal" } });

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.05, duration: 0.4 }}
      className="rounded-3xl border border-border bg-card p-5 sm:p-6 space-y-5"
    >
      <div className="flex items-start gap-4">
        <div className="w-12 h-12 rounded-2xl bg-accent flex items-center justify-center text-primary shrink-0">
          <Icon className="w-6 h-6" />
        </div>
        <div className="min-w-0 flex-1">
          <h3 className="font-heading text-2xl font-semibold leading-tight">{t(`service_${service.id}`)}</h3>
          <div className="mt-1.5 flex flex-wrap gap-x-4 gap-y-1 text-sm text-muted-foreground">
            <span className="flex items-center gap-1.5"><CalendarDays className="w-4 h-4" />{formatDate(request.appointment_date, locale)}</span>
            <span className="flex items-center gap-1.5"><Clock className="w-4 h-4" />{request.appointment_time}</span>
            {request.technician && (
              <span className="flex items-center gap-1.5 text-primary"><UserCog className="w-4 h-4" />{request.technician}</span>
            )}
          </div>
        </div>
        {cancellable && (
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <button className="shrink-0 text-sm text-destructive border border-destructive/40 rounded-full px-3 py-1.5 hover:bg-destructive/10 transition-colors">
                {t("cancel")}
              </button>
            </AlertDialogTrigger>
            <AlertDialogContent className="rounded-3xl">
              <AlertDialogHeader>
                <AlertDialogTitle className="font-heading text-2xl">{t("cancel_title")}</AlertDialogTitle>
                <AlertDialogDescription>
                  {t("cancel_desc")}
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>{t("cancel_back")}</AlertDialogCancel>
                <AlertDialogAction onClick={cancel} disabled={busy} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                  {busy ? t("cancel_busy") : t("cancel_confirm")}
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        )}
      </div>
      <StatusTracker status={request.status} />
      {request.description && <p className="text-sm text-muted-foreground border-t border-border pt-4">{request.description}</p>}
      {request.iban_visible && <IbanCard />}
    </motion.div>
  );
}