import React from "react";
import { Check, X } from "lucide-react";
import { STATUS_STEPS } from "@/lib/serviceConfig";
import { useLanguage } from "@/lib/i18n";

export default function StatusTracker({ status }) {
  const { t } = useLanguage();
  if (status === "iptal") {
    return (
      <div className="flex items-center gap-2 rounded-xl bg-muted px-3 py-2 text-sm text-muted-foreground">
        <X className="w-4 h-4" /> {t("canceled_msg")}
      </div>
    );
  }
  if (status === "reddedildi") {
    return (
      <div className="flex items-center gap-2 rounded-xl bg-destructive/10 text-destructive px-3 py-2 text-sm">
        <X className="w-4 h-4" /> {t("rejected_msg")}
      </div>
    );
  }
  const current = STATUS_STEPS.findIndex((s) => s.id === status);
  return (
    <div className="grid grid-cols-4 gap-1">
      {STATUS_STEPS.map((step, i) => {
        const done = i <= current;
        return (
          <div key={step.id} className="flex flex-col items-center text-center gap-2 min-w-[44px] min-h-[44px]">
            <div className="flex items-center w-full">
              <div className={`h-px flex-1 ${i === 0 ? "opacity-0" : done ? "bg-primary" : "bg-border"}`} />
              <div
                className={`w-11 h-11 rounded-full flex items-center justify-center border transition-all duration-500 ${
                  done ? "bg-primary border-primary text-primary-foreground" : "border-border text-muted-foreground"
                } ${i === current ? "ring-4 ring-primary/20" : ""}`}
              >
                {done ? <Check className="w-5 h-5" /> : <span className="text-xs">{i + 1}</span>}
              </div>
              <div className={`h-px flex-1 ${i === 3 ? "opacity-0" : i < current ? "bg-primary" : "bg-border"}`} />
            </div>
            <span className={`text-sm leading-tight ${done ? "text-foreground" : "text-muted-foreground"}`}>
              {t(`status_${step.id}`)}
            </span>
          </div>
        );
      })}
    </div>
  );
}