import React from "react";
import { Landmark } from "lucide-react";
import CopyButton from "@/components/common/CopyButton";
import { SHOP } from "@/lib/serviceConfig";
import { useLanguage } from "@/lib/i18n";

export default function IbanCard() {
  const { t } = useLanguage();
  return (
    <div className="rounded-2xl border border-primary/30 bg-accent/40 p-4 space-y-3">
      <div className="flex items-center gap-2 text-primary text-sm uppercase tracking-[0.2em] font-semibold">
        <Landmark className="w-4 h-4" /> {t("iban_title")}
      </div>
      <div className="flex items-center justify-between gap-3">
        <div className="min-w-0">
          <p className="text-sm text-muted-foreground">{t("iban_holder")}</p>
          <p className="font-semibold text-sm truncate">{SHOP.ibanHolder}</p>
        </div>
        <CopyButton value={SHOP.ibanHolder} label={t("iban_copy_name")} />
      </div>
      <div className="flex items-center justify-between gap-3">
        <div className="min-w-0">
          <p className="text-sm text-muted-foreground">IBAN</p>
          <p className="font-mono text-sm tracking-wide break-all">{SHOP.iban}</p>
        </div>
        <CopyButton value={SHOP.iban.replace(/\s/g, "")} label={t("iban_copy")} />
      </div>
    </div>
  );
}