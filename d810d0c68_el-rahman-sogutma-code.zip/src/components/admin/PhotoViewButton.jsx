import React, { useState } from "react";
import { Image as ImageIcon, Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useLanguage } from "@/lib/i18n";

export default function PhotoViewButton({ uri }) {
  const { t } = useLanguage();
  const [url, setUrl] = useState(null);
  const [loading, setLoading] = useState(false);

  const load = async () => {
    setLoading(true);
    const { signed_url } = await base44.integrations.Core.CreateFileSignedUrl({ file_uri: uri, expires_in: 600 });
    setUrl(signed_url);
    setLoading(false);
  };

  if (url) return <img src={url} alt="" className="w-full max-h-72 object-cover rounded-2xl border border-border" />;
  return (
    <button type="button" onClick={load} className="flex items-center gap-2 text-sm text-primary">
      {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <ImageIcon className="w-4 h-4" />} {t("show_photo")}
    </button>
  );
}