import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { CalendarDays, Clock, MapPin, Phone, UserCog } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { serviceById, formatDate } from "@/lib/serviceConfig";
import { useLanguage } from "@/lib/i18n";
import AdminActions from "@/components/admin/AdminActions";
import EditRequestDialog from "@/components/admin/EditRequestDialog";
import PhotoViewButton from "@/components/admin/PhotoViewButton";
import IbanCard from "@/components/requests/IbanCard";

export default function AdminRequestCard({ request, onChanged }) {
  const [editing, setEditing] = useState(false);
  const { t, locale } = useLanguage();
  const service = serviceById(request.service_type);
  const { data: technicians = [] } = useQuery({
    queryKey: ["technicians"],
    queryFn: () => base44.entities.Technician.list("-created_date", 200),
  });

  const update = async (data) => {
    await base44.entities.ServiceRequest.update(request.id, data);
    onChanged();
  };
  const onDelete = async () => {
    await base44.entities.ServiceRequest.delete(request.id);
    onChanged();
  };

  return (
    <div className="rounded-3xl border border-border bg-card p-5 space-y-4">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="font-heading text-2xl font-semibold leading-tight">{request.customer_name}</p>
          <p className="text-sm text-primary mt-0.5">{t(`service_${service.id}`)}</p>
        </div>
        <span className="shrink-0 rounded-full bg-accent text-accent-foreground px-3 py-1 text-sm font-medium">{t(`status_${request.status}`)}</span>
      </div>
      <div className="grid sm:grid-cols-2 gap-2 text-sm text-muted-foreground">
        <span className="flex items-center gap-2"><Phone className="w-4 h-4" />{request.customer_phone}</span>
        <span className="flex items-center gap-2"><CalendarDays className="w-4 h-4" />{formatDate(request.appointment_date, locale)}</span>
        <span className="flex items-center gap-2"><Clock className="w-4 h-4" />{request.appointment_time}</span>
        {request.technician && <span className="flex items-center gap-2"><UserCog className="w-4 h-4" />{request.technician}</span>}
        {request.address && <span className="flex items-start gap-2 sm:col-span-2"><MapPin className="w-4 h-4 mt-0.5 shrink-0" />{request.address}</span>}
      </div>
      {request.description && <p className="text-sm border-l-2 border-primary/50 pl-3">{request.description}</p>}
      {request.photo_uri && <PhotoViewButton uri={request.photo_uri} />}
      {(request.repair_report || request.price != null) && (
        <div className="rounded-2xl border border-primary/30 bg-accent/40 p-4 space-y-1">
          <p className="text-sm uppercase tracking-[0.2em] text-primary font-semibold">{t("report_title")}</p>
          {request.repair_report && <p className="text-sm">{request.repair_report}</p>}
          {request.price != null && <p className="text-sm font-semibold text-primary">{request.price} ₺</p>}
        </div>
      )}
      {request.iban_visible && <IbanCard />}
      <AdminActions request={request} update={update} onEdit={() => setEditing(true)} onDelete={onDelete} />
      {editing && <EditRequestDialog request={request} technicians={technicians} open={editing} onOpenChange={setEditing} onSave={update} />}
    </div>
  );
}