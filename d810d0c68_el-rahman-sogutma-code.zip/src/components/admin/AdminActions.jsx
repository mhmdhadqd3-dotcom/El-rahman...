import React from "react";
import { Link } from "react-router-dom";
import { Check, X, Pencil, Phone, Navigation, MessageCircle, Eye, EyeOff, CheckCheck, Trash2 } from "lucide-react";
import { useLanguage } from "@/lib/i18n";
import useRequestUpdate from "@/hooks/useRequestUpdate";
import {
  AlertDialog, AlertDialogTrigger, AlertDialogContent, AlertDialogHeader,
  AlertDialogTitle, AlertDialogDescription, AlertDialogFooter, AlertDialogCancel, AlertDialogAction,
} from "@/components/ui/alert-dialog";

const btn = "flex items-center justify-center gap-1.5 h-11 rounded-xl text-sm font-medium border transition-colors";
const ghost = `${btn} border-border bg-muted/40 hover:border-primary/50`;

export default function AdminActions({ request, onEdit, onDelete }) {
  const { t } = useLanguage();
  const { mutate: updateRequest } = useRequestUpdate();
  const s = request.status;
  const openLocation = () => {
    const q = request.latitude ? `${request.latitude},${request.longitude}` : encodeURIComponent(request.address || "");
    window.open(`https://www.google.com/maps/dir/?api=1&destination=${q}`, "_blank");
    if (s === "alindi" || s === "onaylandi") updateRequest({ id: request.id, data: { status: "yolda" } });
  };

  return (
    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
      {s === "alindi" && <>
        <button onClick={() => updateRequest({ id: request.id, data: { status: "onaylandi" } })} className={`${btn} bg-primary text-primary-foreground border-primary`}><Check className="w-4 h-4" />{t("approve")}</button>
        <button onClick={() => updateRequest({ id: request.id, data: { status: "reddedildi" } })} className={`${btn} border-destructive/40 text-destructive hover:bg-destructive/10`}><X className="w-4 h-4" />{t("reject")}</button>
      </>}
      {s === "yolda" && <button onClick={() => updateRequest({ id: request.id, data: { status: "tamamlandi" } })} className={`${btn} bg-primary text-primary-foreground border-primary`}><CheckCheck className="w-4 h-4" />{t("done")}</button>}
      <button onClick={onEdit} className={ghost}><Pencil className="w-4 h-4" />{t("edit")}</button>
      <a href={`tel:${request.customer_phone}`} className={ghost}><Phone className="w-4 h-4" />{t("call")}</a>
      {(request.latitude || request.address) && <button onClick={openLocation} className={ghost}><Navigation className="w-4 h-4" />{t("location")}</button>}
      {request.created_by_id && <Link to={`/mesajlar?c=${request.created_by_id}`} className={ghost}><MessageCircle className="w-4 h-4" />{t("message")}</Link>}
      <button onClick={() => updateRequest({ id: request.id, data: { iban_visible: !request.iban_visible } })}
        className={request.iban_visible ? `${btn} border-primary text-primary bg-accent` : ghost}>
        {request.iban_visible ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
        {request.iban_visible ? t("iban_hide") : t("iban_show")}
      </button>
      <AlertDialog>
        <AlertDialogTrigger asChild>
          <button className={`${btn} border-destructive/40 text-destructive hover:bg-destructive/10`}><Trash2 className="w-4 h-4" />{t("delete")}</button>
        </AlertDialogTrigger>
        <AlertDialogContent className="rounded-3xl">
          <AlertDialogHeader>
            <AlertDialogTitle className="font-heading text-2xl">{t("delete_title")}</AlertDialogTitle>
            <AlertDialogDescription>
              {t("delete_desc")}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>{t("cancel_back")}</AlertDialogCancel>
            <AlertDialogAction onClick={onDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">{t("delete")}</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}