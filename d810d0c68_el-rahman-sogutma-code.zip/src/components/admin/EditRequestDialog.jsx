import React, { useState } from "react";
import { ChevronDown, Loader2 } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Drawer, DrawerContent, DrawerHeader, DrawerTitle, DrawerTrigger } from "@/components/ui/drawer";
import { useIsMobile } from "@/hooks/use-mobile";
import DateTimePicker from "@/components/booking/DateTimePicker";
import { useLanguage } from "@/lib/i18n";

export default function EditRequestDialog({ request, technicians, open, onOpenChange, onSave }) {
  const { t } = useLanguage();
  const isMobile = useIsMobile();
  const [sheetOpen, setSheetOpen] = useState(false);
  const [techId, setTechId] = useState(request.technician_id || "");
  const [date, setDate] = useState(request.appointment_date);
  const [time, setTime] = useState(request.appointment_time);
  const [report, setReport] = useState(request.repair_report || "");
  const [price, setPrice] = useState(request.price ?? "");
  const [saving, setSaving] = useState(false);

  const save = async () => {
    setSaving(true);
    const tech = technicians.find((t) => t.id === techId);
    await onSave({
      technician: tech?.name || "",
      technician_id: techId,
      appointment_date: date,
      appointment_time: time,
      repair_report: report,
      price: price === "" || price === null ? null : Number(price),
    });
    setSaving(false);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="rounded-3xl max-w-md">
        <DialogHeader><DialogTitle className="font-heading text-2xl">{t("edit_title")}</DialogTitle></DialogHeader>
        <div className="space-y-2">
          <label className="text-xs uppercase tracking-wider text-muted-foreground">{t("technician")}</label>
          {isMobile ? (
            <Drawer open={sheetOpen} onOpenChange={setSheetOpen}>
              <DrawerTrigger asChild>
                <button type="button"
                  className="flex h-11 w-full items-center justify-between rounded-xl border border-input bg-transparent px-3 py-2 text-sm text-left">
                  {technicians.find((t) => t.id === techId)?.name || t("tech_select")}
                  <ChevronDown className="w-4 h-4 opacity-50 shrink-0" />
                </button>
              </DrawerTrigger>
              <DrawerContent className="rounded-3xl">
                <div className="mx-auto w-full max-w-md px-4 pb-6">
                  <DrawerHeader className="px-0">
                    <DrawerTitle className="font-heading text-xl">{t("tech_select")}</DrawerTitle>
                  </DrawerHeader>
                  <div className="space-y-1">
                    {technicians.map((tech) => (
                      <button key={tech.id} type="button"
                        onClick={() => { setTechId(tech.id); setSheetOpen(false); }}
                        className={`w-full h-12 px-4 rounded-2xl text-left text-sm transition-colors ${tech.id === techId ? "bg-accent text-primary font-semibold" : "hover:bg-accent/50"}`}>
                        {tech.name}
                      </button>
                    ))}
                  </div>
                </div>
              </DrawerContent>
            </Drawer>
          ) : (
            <Select value={techId} onValueChange={setTechId}>
              <SelectTrigger className="h-11"><SelectValue placeholder={t("tech_select")} /></SelectTrigger>
              <SelectContent>
                {technicians.map((t) => <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>)}
              </SelectContent>
            </Select>
          )}
        </div>
        <div className="space-y-2">
          <label className="text-xs uppercase tracking-wider text-muted-foreground">{t("date_time")}</label>
          <DateTimePicker date={date} time={time} onDate={setDate} onTime={setTime} />
        </div>
        <div className="space-y-2">
          <label className="text-xs uppercase tracking-wider text-muted-foreground">{t("report_label")}</label>
          <Textarea rows={3} value={report} onChange={(e) => setReport(e.target.value)} placeholder={t("report_ph")} />
        </div>
        <div className="space-y-2">
          <label className="text-xs uppercase tracking-wider text-muted-foreground">{t("price_label")}</label>
          <Input type="number" inputMode="decimal" min="0" value={price} onChange={(e) => setPrice(e.target.value)} placeholder="0" className="h-11" />
        </div>
        <Button onClick={save} disabled={saving} className="h-11 rounded-full">
          {saving && <Loader2 className="w-4 h-4 mr-2 animate-spin" />} {t("save")}
        </Button>
      </DialogContent>
    </Dialog>
  );
}