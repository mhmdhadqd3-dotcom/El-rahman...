import React from "react";
import { useLanguage } from "@/lib/i18n";

export default function ConversationList({ messages, selected, onSelect }) {
  const { t, locale } = useLanguage();
  const threads = [];
  const seen = new Set();
  messages.forEach((m) => {
    if (seen.has(m.customer_id)) return;
    seen.add(m.customer_id);
    threads.push(m);
  });

  if (threads.length === 0) return <p className="text-center text-muted-foreground py-16">{t("no_customer_msgs")}</p>;

  return (
    <div className="space-y-2">
      {threads.map((m) => (
        <button key={m.customer_id} onClick={() => onSelect(m.customer_id, m.customer_name)}
          className={`w-full text-left rounded-2xl border p-4 transition-colors ${selected === m.customer_id ? "border-primary bg-accent" : "border-border bg-card hover:border-primary/40"}`}>
          <div className="flex items-center justify-between gap-2">
            <p className="font-medium truncate">{m.customer_name || t("customer")}</p>
            <span className="text-xs text-muted-foreground shrink-0">{new Date(m.created_date).toLocaleDateString(locale)}</span>
          </div>
          <p className="text-sm text-muted-foreground truncate mt-0.5">{m.sender === "admin" ? t("you") : ""}{m.text}</p>
        </button>
      ))}
    </div>
  );
}