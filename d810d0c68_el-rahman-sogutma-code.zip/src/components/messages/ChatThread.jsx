import React, { useEffect, useRef, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Send, Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useLanguage } from "@/lib/i18n";

export default function ChatThread({ customerId, customerName, role }) {
  const { t, locale } = useLanguage();
  const queryClient = useQueryClient();
  const [text, setText] = useState("");
  const endRef = useRef(null);
  const { data: messages = [], isLoading } = useQuery({
    queryKey: ["messages", customerId],
    queryFn: () => base44.entities.Message.filter({ customer_id: customerId }, "created_date", 300),
  });

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages.length]);

  const { mutate: sendMessage, isPending: sending } = useMutation({
    mutationFn: (text) => base44.entities.Message.create({ customer_id: customerId, customer_name: customerName, sender: role, text }),
    onMutate: async (text) => {
      await queryClient.cancelQueries({ queryKey: ["messages"] });
      const prev = queryClient.getQueryData(["messages", customerId]);
      queryClient.setQueryData(["messages", customerId], (old = []) => [
        ...old,
        { id: `optimistic-${Date.now()}`, sender: role, text, created_date: new Date().toISOString(), customer_id: customerId },
      ]);
      return { prev };
    },
    onError: (_error, _text, context) => {
      if (context?.prev !== undefined) queryClient.setQueryData(["messages", customerId], context.prev);
    },
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: ["messages"] });
    },
  });

  const send = (e) => {
    e.preventDefault();
    const value = text.trim();
    if (!value) return;
    setText("");
    sendMessage(value);
  };

  return (
    <div className="flex flex-col rounded-3xl border border-border bg-card overflow-hidden h-[60vh] min-h-[380px]">
      <div className="flex-1 overflow-y-auto overscroll-none p-4 space-y-2.5" style={{ overscrollBehavior: "none" }}>
        {isLoading && <div className="flex justify-center py-10"><Loader2 className="w-5 h-5 animate-spin text-primary" /></div>}
        {!isLoading && messages.length === 0 && (
          <p className="text-center text-sm text-muted-foreground py-10">
            {role === "customer" ? t("chat_empty_customer") : t("chat_empty_admin")}
          </p>
        )}
        {messages.map((m) => {
          const mine = m.sender === role;
          return (
            <div key={m.id} className={`flex ${mine ? "justify-end" : "justify-start"}`}>
              <div className={`max-w-[80%] rounded-2xl px-4 py-2.5 text-sm ${mine ? "bg-primary text-primary-foreground rounded-br-md" : "bg-muted rounded-bl-md"}`}>
                <p className="whitespace-pre-wrap break-words">{m.text}</p>
                <p className={`text-xs mt-1 ${mine ? "text-black/60" : "text-muted-foreground"}`}>
                  {new Date(m.created_date).toLocaleString(locale, { hour: "2-digit", minute: "2-digit", day: "numeric", month: "short" })}
                </p>
              </div>
            </div>
          );
        })}
        <div ref={endRef} />
      </div>
      <form onSubmit={send} className="flex items-center gap-2 border-t border-border p-3">
        <input value={text} onChange={(e) => setText(e.target.value)} placeholder={t("msg_ph")}
          className="flex-1 h-11 rounded-full bg-muted px-4 text-sm outline-none focus:ring-2 focus:ring-primary/40" />
        <button type="submit" disabled={sending || !text.trim()} className="w-11 h-11 rounded-full bg-primary text-primary-foreground flex items-center justify-center disabled:opacity-40" aria-label="Gönder">
          {sending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
        </button>
      </form>
    </div>
  );
}